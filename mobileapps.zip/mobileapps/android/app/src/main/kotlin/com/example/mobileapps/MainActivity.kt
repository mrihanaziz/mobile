package com.example.mobileapps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
